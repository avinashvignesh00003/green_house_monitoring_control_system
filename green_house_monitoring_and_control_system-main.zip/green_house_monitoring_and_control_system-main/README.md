# green_house_monitoring_and_control_system
the project is based on human less maintaince of agriculture.in this moisture of soil,temperature and light intensity of the place will maintained automatically.
